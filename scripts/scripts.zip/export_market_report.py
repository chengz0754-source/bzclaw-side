from __future__ import annotations

import argparse
import csv
import json
import re
import sys
import time
import zipfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from playwright.sync_api import Error, TimeoutError as PlaywrightTimeoutError, sync_playwright


try:
    sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")
    sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")
except Exception:
    pass


ROOT = Path(__file__).resolve().parents[1]
PROFILE_DIR = ROOT / "playwright" / "profiles" / "sellersprite-main"
DEFAULT_OUTPUT_DIR = ROOT / "runs" / "manual" / "10_market"
DEFAULT_LOG_DIR = ROOT / "logs" / "market_exports"
CURRENT_GOAL_RELATIVE = Path("inputs/selection_run_current/00_选品运行目标与边界.csv")
CURRENT_ENTRY_RELATIVE = Path("inputs/selection_run_current/01_市场入口与筛选参数.csv")
MARKET_URL = "https://www.sellersprite.com/v2/market-research"
CSV_READ_ENCODINGS = ("utf-8-sig", "utf-8", "gb18030", "gbk")
DEFAULT_KEYWORD = "Squeeze Toys"
DEFAULT_SITE = "US"
DEFAULT_DAYS = 30
DEFAULT_NEW_PRODUCT_WINDOW = "6"
DEFAULT_SAMPLE_TOP_N = 100
DEFAULT_HEAD_TOP_N = 10

SITE_LABELS = {
    "US": "美国站(com)",
    "JP": "日本站(co.jp)",
    "UK": "英国站(co.uk)",
    "DE": "德国站(de)",
    "FR": "法国站(fr)",
    "IT": "意大利(it)",
    "ES": "西班牙(es)",
    "CA": "加拿大(ca)",
    "IN": "印度站(in)",
    "MX": "墨西哥(mx)",
}

NEW_PRODUCT_WINDOW_VALUES = {
    "1": "1",
    "1m": "1",
    "1mo": "1",
    "3": "3",
    "3m": "3",
    "3mo": "3",
    "6": "6",
    "6m": "6",
    "6mo": "6",
    "12": "12",
    "12m": "12",
    "12mo": "12",
}

NEW_PRODUCT_DAYS_TO_WINDOW = {
    "30": "1",
    "90": "3",
    "180": "6",
    "365": "12",
}

HEAD_TOP_VALUES = {"3", "5", "10", "20"}

SEARCH_INPUT_SELECTOR = "input[name='departmentKeyword']"
NEW_PRODUCT_SELECT_SELECTOR = "select[name='newReleaseNumSelect']"
HEAD_TOP_SELECT_SELECTOR = "select[name='topNSelect']"

FILTER_BUTTON_TEXT = "筛选市场"
EXPORT_BUTTON_TEXT = "导出Excel"
MONTH_LAST_30_LABEL = "最近30天"


class MarketExportError(RuntimeError):
    pass


class ExportExecutionError(MarketExportError):
    def __init__(self, message: str, attempts: list[dict[str, Any]]) -> None:
        super().__init__(message)
        self.attempts = attempts


@dataclass
class ExportArgs:
    keyword: str
    site: str
    days: int
    new_product_window: str
    sample_top_n: int
    head_top_n: int
    output_dir: Path
    log_dir: Path
    dry_run: bool
    max_attempts: int
    retry_wait_seconds: float
    context_row_index: int | None
    run_name: str
    context_source: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Export a SellerSprite market report using the local dedicated automation profile.",
    )
    parser.add_argument("--keyword", default=None)
    parser.add_argument("--site", default=None)
    parser.add_argument("--days", type=int, default=None)
    parser.add_argument("--new-product-window", default=None)
    parser.add_argument("--sample-top-n", type=int, default=None)
    parser.add_argument("--head-top-n", type=int, default=None)
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    parser.add_argument("--log-dir", default=str(DEFAULT_LOG_DIR))
    parser.add_argument("--context-row-index", type=int, default=None)
    parser.add_argument("--dry-run", action="store_true", help="Only resolve controls, naming, and logs; do not launch Playwright.")
    parser.add_argument("--max-attempts", type=int, default=2, help="Maximum export attempts, including the first attempt.")
    parser.add_argument("--retry-wait-seconds", type=float, default=3.0)
    return parser.parse_args()


def ensure_within_repo(path: Path, label: str) -> Path:
    resolved = path.resolve()
    if not resolved.is_relative_to(ROOT.resolve()):
        raise MarketExportError(f"{label} is outside the repo root: {resolved}")
    return resolved


def load_csv_rows(path: Path) -> list[list[str]]:
    raw_bytes = path.read_bytes()
    decode_errors: list[str] = []
    for encoding in CSV_READ_ENCODINGS:
        try:
            return list(csv.reader(raw_bytes.decode(encoding).splitlines()))
        except UnicodeDecodeError as exc:
            decode_errors.append(f"{encoding}@{exc.start}:{exc.reason}")
    detail = " | ".join(decode_errors) or "unknown decode failure"
    raise MarketExportError(f"Failed to read CSV with supported encodings: {path} | {detail}")


def load_current_input_context(row_index: int) -> dict[str, str]:
    if row_index <= 0:
        raise MarketExportError("--context-row-index must be >= 1.")

    goal_path = ROOT / CURRENT_GOAL_RELATIVE
    entry_path = ROOT / CURRENT_ENTRY_RELATIVE
    if not goal_path.exists():
        raise MarketExportError(f"Current goal CSV is missing: {goal_path}")
    if not entry_path.exists():
        raise MarketExportError(f"Current market entry CSV is missing: {entry_path}")

    goal_rows = load_csv_rows(goal_path)
    entry_rows = load_csv_rows(entry_path)
    if len(goal_rows) < 2:
        raise MarketExportError(f"Current goal CSV has no data row: {goal_path}")
    if len(entry_rows) <= row_index:
        raise MarketExportError(
            f"--context-row-index {row_index} is out of range for {entry_path}; available rows: {max(len(entry_rows) - 1, 0)}"
        )

    goal_map = {header: goal_rows[1][idx] if idx < len(goal_rows[1]) else "" for idx, header in enumerate(goal_rows[0])}
    entry_map = {header: entry_rows[row_index][idx] if idx < len(entry_rows[row_index]) else "" for idx, header in enumerate(entry_rows[0])}
    return {
        "goal_run_name": goal_map.get("运行名称", "").strip(),
        "entry_run_name": entry_map.get("运行名称", "").strip(),
        "keyword": entry_map.get("方向词", "").strip(),
        "site": entry_map.get("站点", "").strip().upper(),
        "days": entry_map.get("时间范围_天", "").strip(),
        "new_product_days": entry_map.get("新品定义_天", "").strip(),
        "sample_top_n": entry_map.get("样本数前N", "").strip(),
        "head_top_n": entry_map.get("头部商品前N", "").strip(),
    }


def normalize_new_product_window(value: str) -> str:
    normalized = str(value).strip().lower()
    if normalized not in NEW_PRODUCT_WINDOW_VALUES:
        raise MarketExportError(
            "--new-product-window must be one of: 1, 3, 6, 12, 1m, 3m, 6m, 12m."
        )
    return NEW_PRODUCT_WINDOW_VALUES[normalized]


def normalize_new_product_window_from_days(value: str) -> str:
    normalized = str(value).strip()
    if not normalized:
        return DEFAULT_NEW_PRODUCT_WINDOW
    if normalized not in NEW_PRODUCT_DAYS_TO_WINDOW:
        raise MarketExportError(
            f"Current input 新品定义_天 is not supported by the verified SellerSprite flow: {normalized}. "
            "Use 30, 90, 180, or 365, or pass --new-product-window explicitly."
        )
    return NEW_PRODUCT_DAYS_TO_WINDOW[normalized]


def parse_int_value(raw_value: str | int | None, field_name: str) -> int:
    try:
        return int(raw_value)  # type: ignore[arg-type]
    except (TypeError, ValueError) as exc:
        raise MarketExportError(f"{field_name} must be an integer value, got: {raw_value!r}") from exc


def resolve_args(namespace: argparse.Namespace) -> ExportArgs:
    context: dict[str, str] = {}
    if namespace.context_row_index is not None:
        context = load_current_input_context(namespace.context_row_index)
        context_source = f"inputs/selection_run_current/01 row {namespace.context_row_index}"
    else:
        context_source = "script defaults"

    keyword = (namespace.keyword or context.get("keyword") or DEFAULT_KEYWORD).strip()
    site = (namespace.site or context.get("site") or DEFAULT_SITE).strip().upper()
    days = namespace.days if namespace.days is not None else parse_int_value(context.get("days") or DEFAULT_DAYS, "时间范围_天")
    if namespace.new_product_window is not None:
        new_product_window = normalize_new_product_window(namespace.new_product_window)
    elif namespace.context_row_index is not None:
        new_product_window = normalize_new_product_window_from_days(context.get("new_product_days", ""))
    else:
        new_product_window = DEFAULT_NEW_PRODUCT_WINDOW
    sample_top_n = (
        namespace.sample_top_n
        if namespace.sample_top_n is not None
        else parse_int_value(context.get("sample_top_n") or DEFAULT_SAMPLE_TOP_N, "样本数前N")
    )
    head_top_n = (
        namespace.head_top_n
        if namespace.head_top_n is not None
        else parse_int_value(context.get("head_top_n") or DEFAULT_HEAD_TOP_N, "头部商品前N")
    )
    output_dir = Path(namespace.output_dir).expanduser()
    log_dir = Path(namespace.log_dir).expanduser()
    if not output_dir.is_absolute():
        output_dir = ROOT / output_dir
    if not log_dir.is_absolute():
        log_dir = ROOT / log_dir
    run_name = context.get("entry_run_name") or context.get("goal_run_name") or ""
    return ExportArgs(
        keyword=keyword,
        site=site,
        days=days,
        new_product_window=new_product_window,
        sample_top_n=sample_top_n,
        head_top_n=head_top_n,
        output_dir=ensure_within_repo(output_dir, "output_dir"),
        log_dir=ensure_within_repo(log_dir, "log_dir"),
        dry_run=bool(namespace.dry_run),
        max_attempts=int(namespace.max_attempts),
        retry_wait_seconds=float(namespace.retry_wait_seconds),
        context_row_index=namespace.context_row_index,
        run_name=run_name,
        context_source=context_source,
    )


def sanitize_keyword(keyword: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9]+", "-", keyword.strip().lower()).strip("-")
    return cleaned or "market"


def recommended_filename(args: ExportArgs, timestamp: datetime) -> str:
    return (
        f"market-report-{args.site.lower()}-{sanitize_keyword(args.keyword)}-"
        f"d{args.days}-new{normalize_new_product_window(args.new_product_window)}m-"
        f"sample{args.sample_top_n}-head{args.head_top_n}-{timestamp.strftime('%Y%m%d_%H%M%S')}.xlsx"
    )


def validate_args(args: ExportArgs) -> None:
    if args.site not in SITE_LABELS:
        supported = ", ".join(sorted(SITE_LABELS))
        raise MarketExportError(f"--site must be one of: {supported}.")
    if args.days != 30:
        raise MarketExportError("Only --days 30 is verified on the current SellerSprite market flow.")
    if args.sample_top_n != 100:
        raise MarketExportError(
            "The current SellerSprite market flow only exposes sample top 100. Use --sample-top-n 100."
        )
    if str(args.head_top_n) not in HEAD_TOP_VALUES:
        raise MarketExportError("--head-top-n must be one of: 3, 5, 10, 20.")
    if args.max_attempts <= 0:
        raise MarketExportError("--max-attempts must be >= 1.")
    if args.retry_wait_seconds < 0:
        raise MarketExportError("--retry-wait-seconds must be >= 0.")
    if not args.keyword:
        raise MarketExportError("--keyword resolved to an empty value.")
    normalize_new_product_window(args.new_product_window)


def ensure_local_auth_profile() -> None:
    if not PROFILE_DIR.exists():
        raise MarketExportError(
            f"Dedicated SellerSprite profile is missing: {PROFILE_DIR}. Run scripts/bootstrap_sellersprite_auth.py first."
        )
    try:
        next(PROFILE_DIR.iterdir())
    except StopIteration as exc:
        raise MarketExportError(
            f"Dedicated SellerSprite profile is empty: {PROFILE_DIR}. Run scripts/bootstrap_sellersprite_auth.py first."
        ) from exc


def build_target_path(output_dir: Path, file_name: str) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    return output_dir / file_name


def validate_download(path: Path) -> None:
    if not path.exists():
        raise MarketExportError(f"Download file was not saved: {path}")
    if path.stat().st_size <= 0:
        raise MarketExportError(f"Downloaded file is empty: {path}")
    if path.suffix.lower() != ".xlsx":
        raise MarketExportError(f"Downloaded file is not an .xlsx workbook: {path.name}")
    try:
        with zipfile.ZipFile(path) as workbook:
            names = set(workbook.namelist())
    except zipfile.BadZipFile as exc:
        raise MarketExportError(f"Downloaded workbook is not a valid XLSX zip container: {path}") from exc
    if "xl/workbook.xml" not in names:
        raise MarketExportError(f"Downloaded workbook is missing xl/workbook.xml: {path}")


def click_visible_button(page, label: str) -> None:
    locator = page.locator(f"button:has-text('{label}')").first
    locator.wait_for(state="visible", timeout=15000)
    locator.click(timeout=15000)


def configure_market_filters(page, args: ExportArgs) -> None:
    site_label = SITE_LABELS[args.site]
    click_visible_button(page, site_label)
    click_visible_button(page, MONTH_LAST_30_LABEL)
    page.locator(NEW_PRODUCT_SELECT_SELECTOR).select_option(normalize_new_product_window(args.new_product_window))
    page.locator(HEAD_TOP_SELECT_SELECTOR).select_option(str(args.head_top_n))
    page.locator(SEARCH_INPUT_SELECTOR).click()
    page.locator(SEARCH_INPUT_SELECTOR).fill(args.keyword)


def iso_now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def append_jsonl(path: Path, record: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(record, ensure_ascii=False) + "\n")


def write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def write_run_record(log_dir: Path, run_label: str, record: dict[str, Any]) -> tuple[Path, Path]:
    log_dir.mkdir(parents=True, exist_ok=True)
    run_log_path = log_dir / f"{run_label}.json"
    latest_run_path = log_dir / "latest_run.json"
    write_json(run_log_path, record)
    write_json(latest_run_path, record)
    append_jsonl(log_dir / "export_runs.jsonl", record)
    if record.get("status") == "FAILED":
        append_jsonl(log_dir / "export_failures.jsonl", record)
    return run_log_path, latest_run_path


def export_report_once(args: ExportArgs, target_path: Path) -> tuple[Path, str]:
    if target_path.exists():
        target_path.unlink()

    with sync_playwright() as playwright:
        context = playwright.chromium.launch_persistent_context(
            user_data_dir=str(PROFILE_DIR),
            channel="msedge",
            headless=False,
            accept_downloads=True,
            viewport={"width": 1600, "height": 900},
        )
        try:
            page = context.pages[0] if context.pages else context.new_page()
            page.goto(MARKET_URL, wait_until="domcontentloaded", timeout=60000)
            page.wait_for_timeout(2000)
            configure_market_filters(page, args)
            click_visible_button(page, FILTER_BUTTON_TEXT)
            export_button = page.locator("button", has_text=EXPORT_BUTTON_TEXT).first
            export_button.wait_for(state="visible", timeout=120000)
            with page.expect_download(timeout=120000) as download_info:
                export_button.click(timeout=15000)
            download = download_info.value
            download.save_as(str(target_path))
            validate_download(target_path)
            return target_path, download.suggested_filename
        except PlaywrightTimeoutError as exc:
            message = (
                "Timed out while waiting for SellerSprite export controls or download. "
                "The local session may be expired; refresh auth with scripts/bootstrap_sellersprite_auth.py."
            )
            raise MarketExportError(message) from exc
        except Error as exc:
            raise MarketExportError(f"Playwright failed during market export: {exc}") from exc
        finally:
            context.close()


def build_run_label(args: ExportArgs, timestamp: datetime) -> str:
    return (
        f"{timestamp.strftime('%Y%m%d_%H%M%S')}-market-export-"
        f"{args.site.lower()}-{sanitize_keyword(args.keyword)}"
    )


def run_export(args: ExportArgs) -> tuple[Path, str, list[dict[str, Any]]]:
    ensure_local_auth_profile()
    run_started = datetime.now()
    target_path = build_target_path(args.output_dir, recommended_filename(args, run_started))
    attempts: list[dict[str, Any]] = []
    last_error: MarketExportError | None = None

    for attempt_index in range(1, args.max_attempts + 1):
        attempt_started = iso_now()
        try:
            saved_path, suggested_filename = export_report_once(args, target_path)
            attempts.append(
                {
                    "attempt": attempt_index,
                    "started_at": attempt_started,
                    "finished_at": iso_now(),
                    "status": "SUCCESS",
                    "target_path": str(saved_path),
                    "seller_suggested_filename": suggested_filename,
                }
            )
            return saved_path, suggested_filename, attempts
        except MarketExportError as exc:
            last_error = exc
            attempts.append(
                {
                    "attempt": attempt_index,
                    "started_at": attempt_started,
                    "finished_at": iso_now(),
                    "status": "FAILED",
                    "target_path": str(target_path),
                    "error": str(exc),
                }
            )
            if attempt_index >= args.max_attempts:
                break
            time.sleep(args.retry_wait_seconds)

    assert last_error is not None
    raise ExportExecutionError(str(last_error), attempts)


def build_record_base(args: ExportArgs, run_label: str, planned_target: Path) -> dict[str, Any]:
    return {
        "run_label": run_label,
        "status": "UNKNOWN",
        "started_at": iso_now(),
        "finished_at": None,
        "runner": "scripts/export_market_report.py",
        "context_source": args.context_source,
        "context_row_index": args.context_row_index,
        "run_name": args.run_name,
        "controls": {
            "keyword": args.keyword,
            "site": args.site,
            "days": args.days,
            "new_product_window_months": normalize_new_product_window(args.new_product_window),
            "sample_top_n": args.sample_top_n,
            "head_top_n": args.head_top_n,
        },
        "raw_layer": {
            "output_dir": str(args.output_dir),
            "target_workbook": str(planned_target),
            "target_file_name": planned_target.name,
        },
        "log_dir": str(args.log_dir),
        "attempts": [],
        "seller_suggested_filename": None,
        "failure_reason": None,
    }


def main() -> int:
    args: ExportArgs | None = None
    record: dict[str, Any] | None = None
    run_log_path: Path | None = None
    latest_run_path: Path | None = None
    try:
        args = resolve_args(parse_args())
        validate_args(args)
        run_started = datetime.now()
        planned_target = build_target_path(args.output_dir, recommended_filename(args, run_started))
        run_label = build_run_label(args, run_started)
        record = build_record_base(args, run_label, planned_target)

        if args.dry_run:
            record["status"] = "DRY_RUN"
            record["finished_at"] = iso_now()
            run_log_path, latest_run_path = write_run_record(args.log_dir, run_label, record)
            print(f"Dry-run only: no browser launched and no workbook downloaded.")
            print(f"Context source: {args.context_source}")
            print(f"Resolved keyword/site/days: {args.keyword} / {args.site} / {args.days}")
            print(
                "Resolved new/sample/head: "
                f"{normalize_new_product_window(args.new_product_window)}m / {args.sample_top_n} / {args.head_top_n}"
            )
            print(f"Planned workbook path: {planned_target}")
            print(f"Run log: {run_log_path}")
            print(f"Latest run pointer: {latest_run_path}")
            return 0

        saved_path, suggested_filename, attempts = run_export(args)
        record["status"] = "SUCCESS"
        record["finished_at"] = iso_now()
        record["attempts"] = attempts
        record["seller_suggested_filename"] = suggested_filename
        record["raw_layer"]["saved_workbook"] = str(saved_path)
        record["raw_layer"]["saved_file_size_bytes"] = saved_path.stat().st_size
        run_log_path, latest_run_path = write_run_record(args.log_dir, run_label, record)
        print(f"Download saved to: {saved_path}")
        print(f"Recommended filename: {saved_path.name}")
        print(f"SellerSprite suggested filename: {suggested_filename}")
        print(f"Run log: {run_log_path}")
        print(f"Latest run pointer: {latest_run_path}")
        return 0
    except MarketExportError as exc:
        if args is not None and record is not None:
            record["status"] = "FAILED"
            record["finished_at"] = iso_now()
            record["failure_reason"] = str(exc)
            if isinstance(exc, ExportExecutionError):
                record["attempts"] = exc.attempts
            run_log_path, latest_run_path = write_run_record(args.log_dir, record["run_label"], record)
            print(f"Failure log: {run_log_path}", file=sys.stderr)
            print(f"Latest run pointer: {latest_run_path}", file=sys.stderr)
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
