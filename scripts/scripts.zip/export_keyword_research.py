from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from playwright.sync_api import sync_playwright

from keyword_chain_common import (
    STORAGE_STATE_PATH,
    KeywordChainError,
    compact_text,
    ensure_within_repo,
    iso_now,
    log_dir_from_namespace,
    output_dir_from_namespace,
    page_guest_markers,
    persist_run_summary,
    resolve_context_from_namespace,
    step2_rule_map,
    traffic_cost_index_from_bid,
    write_json_atomic,
)


KEYWORD_RESEARCH_URL = "https://www.sellersprite.com/v2/keyword-research"
RAW_FILE_NAME = "keyword_research_raw.json"

DEPARTMENT_BY_HINT = {
    "arts, crafts & sewing": "arts-crafts",
    "automotive parts & accessories": "automotive",
    "baby": "baby-products",
    "beauty & personal care": "beauty",
    "camera and photo": "photo",
    "cell phones & accessories": "mobile",
    "clothing, shoes & jewelry": "fashion",
    "computers": "computers",
    "electronics": "electronics",
    "grocery & gourmet food": "grocery",
    "handmade": "handmade",
    "health, household & baby care": "hpc",
    "home & kitchen": "kitchen",
    "industrial & scientific": "industrial",
    "musical instruments": "mi",
    "office products": "office-products",
    "patio, lawn & garden": "lawngarden",
    "pet supplies": "pets",
    "sports & outdoors": "sporting",
    "tools & home improvement": "tools",
    "toys & games": "toys-and-games",
    "video games": "videogames",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Collect SellerSprite keyword-research results into a repo-local raw JSON artifact.",
    )
    parser.add_argument("--context-row-index", type=int, default=1)
    parser.add_argument("--run-name", default=None)
    parser.add_argument("--direction-id", default=None)
    parser.add_argument("--keyword", default=None)
    parser.add_argument("--category-hint", default=None)
    parser.add_argument("--site", default=None)
    parser.add_argument("--days", type=int, default=None)
    parser.add_argument("--sample-top-n", type=int, default=None)
    parser.add_argument("--month", default=None, help="Override SellerSprite month, e.g. 202603.")
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--log-dir", default=None)
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def page_snapshot(page) -> dict[str, Any]:
    body_text = page.locator("body").inner_text(timeout=15000)
    title = page.title()
    return {
        "url": page.url,
        "title": title,
        "guest_markers": page_guest_markers(body_text),
        "body_excerpt": compact_text(body_text)[:1200],
    }


def extract_tables(page) -> list[dict[str, Any]]:
    return page.evaluate(
        """
        () => Array.from(document.querySelectorAll('table')).map((table, tableIndex) => ({
          tableIndex,
          headers: Array.from(table.querySelectorAll('thead th, th')).map(
            (cell) => (cell.innerText || '').replace(/\\s+/g, ' ').trim()
          ),
          rows: Array.from(table.querySelectorAll('tbody tr')).map(
            (row) => Array.from(row.querySelectorAll('td')).map(
              (cell) => (cell.innerText || '').replace(/\\s+/g, ' ').trim()
            )
          ).filter((cells) => cells.length > 0)
        })).filter((table) => table.headers.length > 0)
        """
    )


def choose_result_table(tables: list[dict[str, Any]]) -> dict[str, Any] | None:
    best_table: dict[str, Any] | None = None
    best_score = -1
    for table in tables:
        headers = " | ".join(str(header) for header in table.get("headers", []))
        score = 0
        if "关键词" in headers:
            score += 3
        if "月搜索量" in headers:
            score += 2
        if "点击总占比" in headers or "点击量" in headers:
            score += 1
        if "PPC竞价" in headers:
            score += 1
        if score > best_score:
            best_score = score
            best_table = table
    return best_table if best_score >= 4 else None


def header_index_map(headers: list[str]) -> dict[str, int]:
    mapping: dict[str, int] = {}
    for index, header in enumerate(headers):
        if "关键词" in header and "词库" not in header:
            mapping["keyword"] = index
        if "类目" in header:
            mapping.setdefault("category", index)
        if "月搜索量" in header and "增长" not in header:
            mapping.setdefault("monthly_searches", index)
        if "月排名" in header or "搜索频率" in header:
            mapping.setdefault("search_rank", index)
        if "增长率" in header:
            mapping.setdefault("growth_pct", index)
        if "点击总占比" in header or "集中度" in header:
            mapping.setdefault("click_concentration_pct", index)
        if "PPC竞价" in header:
            mapping.setdefault("ppc_bid", index)
    return mapping


def first_number(text: str) -> str:
    match = re.search(r"-?\d+(?:\.\d+)?", text.replace(",", ""))
    return match.group(0) if match else ""


def department_value_from_hint(category_hint: str) -> str:
    return DEPARTMENT_BY_HINT.get(category_hint.strip().casefold(), "")


def fill_rule_filters(page, month: str | None) -> dict[str, str]:
    rule_map = step2_rule_map()
    min_searches = rule_map["S2_MIN_SEARCH_VOLUME"]["threshold_value"]
    min_growth = rule_map["S2_MIN_GROWTH_PCT"]["threshold_value"]
    max_click = rule_map["S2_MAX_CLICK_CONCENTRATION"]["threshold_value"]
    max_bid = str(float(rule_map["S2_MAX_TRAFFIC_COST_INDEX"]["threshold_value"]) / 100.0)

    page.locator("input[name='minSearches']").fill(min_searches)
    page.locator("input[name='minGrowth']").fill(min_growth)
    page.locator("input[name='maxMonopolyClickRate']").fill(max_click)
    page.locator("input[name='maxBid']").fill(max_bid)
    if month:
        page.select_option("select[name='month']", value=month)
    return {
        "min_searches": min_searches,
        "min_growth_pct": min_growth,
        "max_click_concentration_pct": max_click,
        "max_bid_usd": max_bid,
        "month": month or page.locator("select[name='month']").input_value(),
    }


def parse_rows(table: dict[str, Any], context, raw_path: Path) -> list[dict[str, Any]]:
    headers = [str(item) for item in table.get("headers", [])]
    mapping = header_index_map(headers)
    rows: list[dict[str, Any]] = []
    for cells in table.get("rows", []):
        if not cells:
            continue
        keyword = cells[mapping["keyword"]].strip() if "keyword" in mapping and mapping["keyword"] < len(cells) else ""
        if not keyword:
            continue
        ppc_bid = cells[mapping["ppc_bid"]] if "ppc_bid" in mapping and mapping["ppc_bid"] < len(cells) else ""
        rows.append(
            {
                "source_module": "KeywordResearch",
                "keyword": keyword,
                "site": context.site,
                "main_category": cells[mapping["category"]].strip() if "category" in mapping and mapping["category"] < len(cells) else context.category_hint,
                "monthly_searches": first_number(cells[mapping["monthly_searches"]]) if "monthly_searches" in mapping and mapping["monthly_searches"] < len(cells) else "",
                "search_frequency_rank": first_number(cells[mapping["search_rank"]]) if "search_rank" in mapping and mapping["search_rank"] < len(cells) else "",
                "growth_pct": first_number(cells[mapping["growth_pct"]]) if "growth_pct" in mapping and mapping["growth_pct"] < len(cells) else "",
                "click_concentration_pct": first_number(cells[mapping["click_concentration_pct"]]) if "click_concentration_pct" in mapping and mapping["click_concentration_pct"] < len(cells) else "",
                "ppc_bid_usd": first_number(ppc_bid),
                "traffic_cost_index": traffic_cost_index_from_bid(first_number(ppc_bid)),
                "captured_at": iso_now(),
                "source_query": context.keyword,
                "source_file": str(raw_path),
                "raw_cells": cells,
            }
        )
    return rows


def main() -> int:
    args = parse_args()
    context = resolve_context_from_namespace(args, require_direction_id=False)
    output_dir = output_dir_from_namespace(args)
    log_dir = log_dir_from_namespace(args)
    raw_artifact_path = ensure_within_repo(output_dir / RAW_FILE_NAME, "raw_artifact_path")
    summary: dict[str, Any] = {
        "timestamp": iso_now(),
        "module": "keyword_research",
        "status": "BLOCKED",
        "reason_code": "",
        "message": "",
        "context_source": context.context_source,
        "运行名称": context.run_name,
        "方向ID": context.direction_id,
        "方向词": context.keyword,
        "站点": context.site,
        "类目提示": context.category_hint,
        "attempted_url": KEYWORD_RESEARCH_URL,
        "final_url": "",
        "page_title": "",
        "guest_markers": [],
        "applied_filters": {},
        "raw_artifact_path": "",
        "raw_row_count": 0,
        "dry_run": bool(args.dry_run),
    }

    try:
        if not STORAGE_STATE_PATH.exists():
            raise KeywordChainError(f"Storage state file is missing: {STORAGE_STATE_PATH}", "AUTH_STATE_MISSING")

        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(channel="msedge", headless=True)
            context_browser = browser.new_context(storage_state=str(STORAGE_STATE_PATH), viewport={"width": 1600, "height": 1400})
            page = context_browser.new_page()
            page.goto(KEYWORD_RESEARCH_URL, wait_until="networkidle", timeout=90000)
            page.wait_for_timeout(2000)
            before_submit = page_snapshot(page)
            summary["guest_markers"] = before_submit["guest_markers"]
            summary["page_title"] = before_submit["title"]

            if page.locator("input[name='includeKeywords']").count() == 0:
                raise KeywordChainError(
                    "Keyword research query form is not visible on the page.",
                    "KEYWORD_RESEARCH_FORM_MISSING",
                )

            page.locator("input[name='includeKeywords']").fill(context.keyword)
            applied_filters = fill_rule_filters(page, args.month)
            department_value = department_value_from_hint(context.category_hint)
            if department_value:
                department_locator = page.locator(f"input[value='{department_value}']")
                if department_locator.count():
                    label_for = department_locator.first.get_attribute("id")
                    if label_for:
                        page.locator(f"label[for='{label_for}']").click(timeout=10000)
                        applied_filters["department"] = department_value
            summary["applied_filters"] = applied_filters

            if args.dry_run:
                summary["status"] = "PASS"
                summary["reason_code"] = "DRY_RUN_ONLY"
                summary["message"] = "Dry-run validated the keyword research page controls and filter mapping without submitting the form."
                summary["final_url"] = page.url
                context_browser.close()
                browser.close()
                persist_run_summary(log_dir, "latest_keyword_research_run.json", "keyword_research_runs.jsonl", summary)
                print(json.dumps(summary, ensure_ascii=False, indent=2))
                return 0

            with page.expect_navigation(wait_until="networkidle", timeout=90000):
                page.evaluate("document.querySelector('#form-condition-search').submit()")

            after_submit = page_snapshot(page)
            summary["final_url"] = after_submit["url"]
            summary["page_title"] = after_submit["title"]
            summary["guest_markers"] = after_submit["guest_markers"]

            if "/w/user/login" in page.url:
                raise KeywordChainError(
                    "Keyword research submission redirected to SellerSprite login. Current repo-local auth state cannot execute live keyword queries.",
                    "KEYWORD_RESEARCH_AUTH_REQUIRED",
                )

            tables = extract_tables(page)
            result_table = choose_result_table(tables)
            if result_table is None:
                raise KeywordChainError(
                    "Keyword research submission completed but no stable result table was detected.",
                    "KEYWORD_RESEARCH_RESULT_TABLE_MISSING",
                )

            rows = parse_rows(result_table, context, raw_artifact_path)
            if not rows:
                raise KeywordChainError(
                    "Keyword research result table was found, but no keyword rows were parsed.",
                    "KEYWORD_RESEARCH_NO_ROWS",
                )

            raw_artifact = {
                "module": "keyword_research",
                "status": "PASS",
                "timestamp": iso_now(),
                "url": page.url,
                "title": page.title(),
                "context": {
                    "run_name": context.run_name,
                    "direction_id": context.direction_id,
                    "keyword": context.keyword,
                    "site": context.site,
                    "category_hint": context.category_hint,
                },
                "filters": applied_filters,
                "rows": rows,
            }
            output_dir.mkdir(parents=True, exist_ok=True)
            write_json_atomic(raw_artifact_path, raw_artifact)

            summary["status"] = "PASS"
            summary["reason_code"] = "PASS"
            summary["message"] = "Keyword research raw rows collected successfully."
            summary["raw_artifact_path"] = str(raw_artifact_path)
            summary["raw_row_count"] = len(rows)
            context_browser.close()
            browser.close()
    except KeywordChainError as exc:
        summary["status"] = "BLOCKED"
        summary["reason_code"] = exc.reason_code
        summary["message"] = str(exc)
    except Exception as exc:
        summary["status"] = "BLOCKED"
        summary["reason_code"] = "KEYWORD_RESEARCH_UNHANDLED_ERROR"
        summary["message"] = str(exc)

    persist_run_summary(log_dir, "latest_keyword_research_run.json", "keyword_research_runs.jsonl", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if summary["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
