from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from playwright.sync_api import sync_playwright

from benchmark_chain_common import (
    BENCHMARK_RAW_ARTIFACT,
    PROFILE_DIR,
    BenchmarkChainError,
    clean_number,
    ensure_within_repo,
    iso_now,
    log_dir_from_namespace,
    output_dir_from_namespace,
    persist_run_summary,
    resolve_context_from_namespace,
    resolve_seed_from_step3,
    write_json_atomic,
)


BENCHMARK_URL = "https://www.sellersprite.com/v3/competitor-lookup"
SITE_LABELS = {
    "US": "美国站",
    "JP": "日本站",
    "UK": "英国站",
    "DE": "德国站",
    "FR": "法国站",
    "IT": "意大利",
    "ES": "西班牙",
    "CA": "加拿大",
    "IN": "印度站",
    "MX": "墨西哥",
}
LAST_30_DAYS_LABEL = "最近30天"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Collect SellerSprite benchmark / competitor results into a repo-local raw JSON artifact.",
    )
    parser.add_argument("--context-row-index", type=int, default=1)
    parser.add_argument("--run-name", default=None)
    parser.add_argument("--direction-id", default=None)
    parser.add_argument("--keyword", default=None)
    parser.add_argument("--category-hint", default=None)
    parser.add_argument("--site", default=None)
    parser.add_argument("--days", type=int, default=None)
    parser.add_argument("--sample-top-n", type=int, default=None)
    parser.add_argument("--max-candidate-samples", type=int, default=None)
    parser.add_argument("--seed-keyword", default=None, help="Debug-only explicit seed keyword override.")
    parser.add_argument("--seed-market-name", default=None, help="Optional market name when --seed-keyword is supplied.")
    parser.add_argument("--step3-gate-csv", default=None)
    parser.add_argument("--step3-cleaned-csv", default=None)
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--log-dir", default=None)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--headless", action="store_true", help="Use headless mode. The verified live path currently keeps this off.")
    return parser.parse_args()


def selected_site_value(page) -> str:
    return page.locator(".market-select input").first.input_value().strip()


def selected_month_value(page) -> str:
    return page.locator(".fliter .el-select").nth(1).locator("input").first.input_value().strip()


def choose_dropdown_value(page, select_locator, target_text: str) -> None:
    current_value = select_locator.locator("input").first.input_value().strip()
    if current_value == target_text:
        return
    select_locator.locator("input").first.click(timeout=10000)
    option = page.locator(".el-select-dropdown__item", has_text=target_text).last
    option.click(timeout=10000)
    page.wait_for_timeout(800)


def configure_filters(page, site_code: str, days: int) -> dict[str, str]:
    if site_code not in SITE_LABELS:
        raise BenchmarkChainError(f"Unsupported benchmark site code: {site_code}", "BENCHMARK_SITE_UNSUPPORTED")
    if days != 30:
        raise BenchmarkChainError(
            "The current benchmark chain is only verified against the SellerSprite '最近30天' surface. Use 时间范围_天=30 for now.",
            "BENCHMARK_DAYS_UNSUPPORTED",
        )

    choose_dropdown_value(page, page.locator(".market-select").first, SITE_LABELS[site_code])
    choose_dropdown_value(page, page.locator(".fliter .el-select").nth(1), LAST_30_DAYS_LABEL)
    return {
        "site_label": selected_site_value(page),
        "month_label": selected_month_value(page),
    }


def benchmark_query_input(page):
    return page.locator(".filter-item.input-wrap input[placeholder*='flashlight']").first


def benchmark_query_button(page):
    return page.locator(".filter-item.input-wrap button").first


def extract_benchmark_items(payload: dict[str, Any]) -> list[dict[str, Any]]:
    data = payload.get("data")
    if not isinstance(data, dict):
        raise BenchmarkChainError("SellerSprite benchmark API did not return a dictionary payload.", "BENCHMARK_API_DATA_INVALID")
    items = data.get("items")
    if not isinstance(items, list):
        raise BenchmarkChainError("SellerSprite benchmark API did not expose an items list.", "BENCHMARK_ITEMS_MISSING")
    normalized_items = [item for item in items if isinstance(item, dict) and str(item.get("asin", "")).strip()]
    if not normalized_items:
        raise BenchmarkChainError("SellerSprite benchmark query returned zero usable ASIN items.", "BENCHMARK_NO_ITEMS")
    return normalized_items


def response_meta(payload: dict[str, Any]) -> dict[str, Any]:
    data = payload.get("data")
    if not isinstance(data, dict):
        return {}
    return {
        "page": data.get("page"),
        "size": data.get("size"),
        "pages": data.get("pages"),
        "total": data.get("total"),
        "took": data.get("took"),
        "order": data.get("order"),
        "guest_visited": data.get("guestVisited"),
        "symbol_checked": data.get("symbolChecked"),
    }


def latest_message(page) -> str:
    if page.locator(".el-message").count() == 0:
        return ""
    return " | ".join(
        page.locator(".el-message").nth(index).inner_text().strip()
        for index in range(page.locator(".el-message").count())
    ).strip()


def main() -> int:
    args = parse_args()
    context = resolve_context_from_namespace(args, require_direction_id=False)
    output_dir = output_dir_from_namespace(args)
    log_dir = log_dir_from_namespace(args)
    raw_artifact_path = ensure_within_repo(output_dir / BENCHMARK_RAW_ARTIFACT, "raw_artifact_path")
    summary: dict[str, Any] = {
        "timestamp": iso_now(),
        "module": "benchmark_export",
        "status": "BLOCKED",
        "reason_code": "",
        "message": "",
        "context_source": context.context_source,
        "运行名称": context.run_name,
        "方向ID": context.direction_id,
        "方向词": context.keyword,
        "站点": context.site,
        "attempted_url": BENCHMARK_URL,
        "final_url": "",
        "page_title": "",
        "query_keyword": "",
        "candidate_market_name": "",
        "market_path": "",
        "applied_filters": {},
        "seed_source_step": "",
        "seed_source_gate_path": "",
        "raw_artifact_path": "",
        "raw_item_count": 0,
        "dry_run": bool(args.dry_run),
        "headless": bool(args.headless),
    }

    try:
        if not PROFILE_DIR.exists():
            raise BenchmarkChainError(f"Persistent profile is missing: {PROFILE_DIR}", "PROFILE_MISSING")

        if args.seed_keyword:
            seed_keyword = str(args.seed_keyword).strip()
            if not seed_keyword:
                raise BenchmarkChainError("--seed-keyword cannot be blank.", "SEED_KEYWORD_BLANK")
            seed = {
                "source_step": "MANUAL_OVERRIDE",
                "source_gate_path": "",
                "source_cleaned_path": "",
                "seed_keyword": seed_keyword,
                "candidate_market_name": str(args.seed_market_name or seed_keyword).strip(),
                "market_path": "",
                "upstream_batch_id": "",
                "upstream_status": "MANUAL_OVERRIDE",
            }
        else:
            resolved_seed = resolve_seed_from_step3(context, args.step3_gate_csv, args.step3_cleaned_csv)
            seed = {
                "source_step": resolved_seed.source_step,
                "source_gate_path": resolved_seed.source_gate_path,
                "source_cleaned_path": resolved_seed.source_cleaned_path,
                "seed_keyword": resolved_seed.seed_keyword,
                "candidate_market_name": resolved_seed.candidate_market_name,
                "market_path": resolved_seed.market_path,
                "upstream_batch_id": resolved_seed.upstream_batch_id,
                "upstream_status": resolved_seed.upstream_status,
            }

        summary["query_keyword"] = seed["seed_keyword"]
        summary["candidate_market_name"] = seed["candidate_market_name"]
        summary["market_path"] = seed["market_path"]
        summary["seed_source_step"] = seed["source_step"]
        summary["seed_source_gate_path"] = seed["source_gate_path"]

        with sync_playwright() as playwright:
            context_browser = playwright.chromium.launch_persistent_context(
                str(PROFILE_DIR),
                channel="msedge",
                headless=bool(args.headless),
                accept_downloads=False,
                viewport={"width": 1600, "height": 1400},
            )
            try:
                page = context_browser.pages[0] if context_browser.pages else context_browser.new_page()
                page.goto(BENCHMARK_URL, wait_until="domcontentloaded", timeout=90000)
                page.wait_for_timeout(5000)
                summary["page_title"] = page.title()
                summary["applied_filters"] = configure_filters(page, context.site, context.days)
                benchmark_query_input(page).click(timeout=10000)
                benchmark_query_input(page).fill(seed["seed_keyword"])

                if args.dry_run:
                    summary["status"] = "PASS"
                    summary["reason_code"] = "DRY_RUN_ONLY"
                    summary["message"] = "Dry-run validated benchmark controls and seed resolution without dispatching the live query."
                    summary["final_url"] = page.url
                    persist_run_summary(log_dir, "latest_benchmark_export_run.json", "benchmark_export_runs.jsonl", summary)
                    print(json.dumps(summary, ensure_ascii=False, indent=2))
                    return 0

                try:
                    with page.expect_response(
                        lambda response: "sellersprite.com/v3/api/competing-lookup" in response.url and response.request.method == "POST",
                        timeout=45000,
                    ) as response_info:
                        benchmark_query_button(page).click(timeout=10000)
                except PlaywrightTimeoutError as exc:
                    message_text = latest_message(page) or "Benchmark query did not emit the expected SellerSprite API request."
                    raise BenchmarkChainError(message_text, "BENCHMARK_QUERY_BLOCKED") from exc

                response = response_info.value
                payload = response.json()
                items = extract_benchmark_items(payload)
                raw_artifact = {
                    "module": "benchmark_export",
                    "status": "PASS",
                    "timestamp": iso_now(),
                    "page_title": page.title(),
                    "query_url": page.url,
                    "benchmark_api_url": response.url,
                    "benchmark_request_method": response.request.method,
                    "benchmark_request_post_data": response.request.post_data or "",
                    "response_meta": response_meta(payload),
                    "context": {
                        "run_name": context.run_name,
                        "direction_id": context.direction_id,
                        "keyword": context.keyword,
                        "category_hint": context.category_hint,
                        "site": context.site,
                        "days": context.days,
                        "sample_top_n": context.sample_top_n,
                        "max_candidate_samples": context.max_candidate_samples,
                    },
                    "seed_context": seed,
                    "applied_filters": summary["applied_filters"],
                    "items": items,
                }
                output_dir.mkdir(parents=True, exist_ok=True)
                write_json_atomic(raw_artifact_path, raw_artifact)

                summary["status"] = "PASS"
                summary["reason_code"] = "PASS"
                summary["message"] = "Benchmark competitor items collected successfully."
                summary["final_url"] = page.url
                summary["raw_artifact_path"] = str(raw_artifact_path)
                summary["raw_item_count"] = len(items)
                summary["response_meta"] = {
                    key: clean_number(value) if key in {"page", "size", "pages", "total", "took"} else value
                    for key, value in response_meta(payload).items()
                }
            finally:
                context_browser.close()
    except BenchmarkChainError as exc:
        summary["status"] = "BLOCKED"
        summary["reason_code"] = exc.reason_code
        summary["message"] = str(exc)
    except Exception as exc:
        summary["status"] = "BLOCKED"
        summary["reason_code"] = "BENCHMARK_EXPORT_UNHANDLED_ERROR"
        summary["message"] = str(exc)

    persist_run_summary(log_dir, "latest_benchmark_export_run.json", "benchmark_export_runs.jsonl", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if summary["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
