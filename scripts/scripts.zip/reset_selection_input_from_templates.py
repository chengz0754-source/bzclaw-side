from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path


PRE_SCREEN_TEMPLATE_FILES = [
    "00_选品运行目标与边界.csv",
    "01_市场入口与筛选参数.csv",
    "02_账号与合规预检查.csv",
    "03_候选市场与候选品初筛池.csv",
]
POST_COST_TEMPLATE_FILE = "04_供应链询价与利润核算.csv"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="从模板目录重置当前输入目录。默认复制 00~03，04 仅在后置询价阶段按需加入。"
    )
    parser.add_argument(
        "--include-post-cost",
        action="store_true",
        help="同时复制后置表 04_供应链询价与利润核算.csv。",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    repo_root = Path(__file__).resolve().parents[1]
    template_dir = repo_root / "templates" / "selection_csv_cn_reference"
    input_dir = repo_root / "inputs" / "selection_run_current"

    template_dir.mkdir(parents=True, exist_ok=True)
    input_dir.mkdir(parents=True, exist_ok=True)

    template_names = list(PRE_SCREEN_TEMPLATE_FILES)
    if args.include_post_cost:
        template_names.append(POST_COST_TEMPLATE_FILE)

    missing = [name for name in template_names if not (template_dir / name).exists()]
    if missing:
        print("初始化失败：模板参考目录缺少以下母版文件：", file=sys.stderr)
        for name in missing:
            print(f"- {name}", file=sys.stderr)
        return 1

    copied = []
    for name in template_names:
        source = template_dir / name
        destination = input_dir / name
        shutil.copy2(source, destination)
        copied.append(destination)

    print("已从模板参考目录重置当前输入目录：")
    for path in copied:
        print(f"- {path}")
    print("说明：默认只复制 00~03；04 仅在候选品进入供应链询价阶段后再加入。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
