import re
from playwright.sync_api import Playwright, sync_playwright, expect


def run(playwright: Playwright) -> None:
    browser = playwright.chromium.launch(channel="msedge", headless=False)
    context = browser.new_context(storage_state="playwright\\auth\\sellersprite.storage_state.json")
    page = context.new_page()
    page.goto("https://www.sellersprite.com/w/user/login?callback=%2Fv3%2Fcompetitor-lookup")
    page.get_by_role("textbox", name="手机号/邮箱/子账号").click()
    page.get_by_role("textbox", name="手机号/邮箱/子账号").fill("15989132504")
    page.get_by_role("textbox", name="手机号/邮箱/子账号").press("Tab")
    page.get_by_role("textbox", name="密 码").fill("5868968Abc")
    page.get_by_role("button", name="立即登录").click()
    page.get_by_role("link", name="工具").click()
    page.locator("#CL").get_by_role("link", name="查竞品").click()
    page.get_by_role("textbox", name="关键词 如:flashlight").click()
    page.get_by_role("textbox", name="关键词 如:flashlight").fill("squeeze toy")
    page.get_by_role("textbox", name="关键词 如:flashlight").press("Enter")
    page.locator(".el-icon-circle-close").click()
    with page.expect_popup() as page1_info:
        page.get_by_role("button", name="前往查看").click()
    page1 = page1_info.value
    page1.locator(".d-inline-block").first.click()
    page1.locator(".d-inline-block").first.click()
    page1.locator(".d-inline-block").first.click()
    page1.locator(".d-inline-block").first.click()

    # ---------------------
    context.close()
    browser.close()


with sync_playwright() as playwright:
    run(playwright)
