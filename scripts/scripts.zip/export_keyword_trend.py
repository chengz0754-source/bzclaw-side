from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from playwright.sync_api import sync_playwright

from keyword_chain_common import (
    PROFILE_DIR,
    KeywordChainError,
    compact_text,
    ensure_within_repo,
    iso_now,
    log_dir_from_namespace,
    output_dir_from_namespace,
    page_guest_markers,
    persist_run_summary,
    resolve_context_from_namespace,
    traffic_cost_index_from_bid,
    write_json_atomic,
)


KEYWORD_TREND_URL = "https://www.sellersprite.com/v3/keyword-miner"
RAW_FILE_NAME = "keyword_trend_raw.json"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Collect SellerSprite keyword-trend research results into a repo-local raw JSON artifact.",
    )
    parser.add_argument("--context-row-index", type=int, default=1)
    parser.add_argument("--run-name", default=None)
    parser.add_argument("--direction-id", default=None)
    parser.add_argument("--keyword", default=None)
    parser.add_argument("--category-hint", default=None)
    parser.add_argument("--site", default=None)
    parser.add_argument("--days", type=int, default=None)
    parser.add_argument("--sample-top-n", type=int, default=None)
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--log-dir", default=None)
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def page_snapshot(page) -> dict[str, Any]:
    body_text = page.locator("body").inner_text(timeout=15000)
    return {
        "url": page.url,
        "title": page.title(),
        "guest_markers": page_guest_markers(body_text),
        "body_excerpt": compact_text(body_text)[:1600],
    }


def extract_tables(page) -> list[dict[str, Any]]:
    return page.evaluate(
        """
        () => Array.from(document.querySelectorAll('table')).map((table, tableIndex) => ({
          tableIndex,
          headers: Array.from(table.querySelectorAll('thead th, th')).map(
            (cell) => (cell.innerText || '').replace(/\\s+/g, ' ').trim()
          ),
          rows: Array.from(table.querySelectorAll('tbody tr')).map(
            (row) => Array.from(row.querySelectorAll('td')).map(
              (cell) => (cell.innerText || '').replace(/\\s+/g, ' ').trim()
            )
          ).filter((cells) => cells.length > 0)
        })).filter((table) => table.headers.length > 0)
        """
    )


def choose_result_table(tables: list[dict[str, Any]]) -> dict[str, Any] | None:
    best_table: dict[str, Any] | None = None
    best_score = -1
    for table in tables:
        headers = " | ".join(str(header) for header in table.get("headers", []))
        score = 0
        if "关键词" in headers:
            score += 3
        if "月搜索量" in headers:
            score += 2
        if "月搜索趋势" in headers:
            score += 2
        if "PPC竞价" in headers:
            score += 1
        if score > best_score:
            best_score = score
            best_table = table
    return best_table if best_score >= 5 else None


def header_index_map(headers: list[str]) -> dict[str, int]:
    mapping: dict[str, int] = {}
    for index, header in enumerate(headers):
        if "关键词" in header:
            mapping.setdefault("keyword", index)
        if "月搜索量" in header:
            mapping.setdefault("monthly_searches", index)
        if "月排名" in header or "ABA月排名" in header:
            mapping.setdefault("search_rank", index)
        if "点击总占比" in header or "ABA集中度" in header:
            mapping.setdefault("click_concentration_pct", index)
        if "PPC竞价" in header:
            mapping.setdefault("ppc_bid", index)
        if "月搜索趋势" in header:
            mapping.setdefault("trend_column", index)
    return mapping


def first_number(text: str) -> str:
    match = re.search(r"-?\d+(?:\.\d+)?", text.replace(",", ""))
    return match.group(0) if match else ""


def parse_rows(table: dict[str, Any], context, raw_path: Path) -> list[dict[str, Any]]:
    headers = [str(item) for item in table.get("headers", [])]
    mapping = header_index_map(headers)
    rows: list[dict[str, Any]] = []
    for cells in table.get("rows", []):
        if not cells:
            continue
        keyword = cells[mapping["keyword"]].strip() if "keyword" in mapping and mapping["keyword"] < len(cells) else ""
        if not keyword:
            continue
        ppc_bid = cells[mapping["ppc_bid"]] if "ppc_bid" in mapping and mapping["ppc_bid"] < len(cells) else ""
        rows.append(
            {
                "source_module": "KeywordTrendResearch",
                "keyword": keyword,
                "site": context.site,
                "main_category": context.category_hint,
                "monthly_searches": first_number(cells[mapping["monthly_searches"]]) if "monthly_searches" in mapping and mapping["monthly_searches"] < len(cells) else "",
                "search_frequency_rank": first_number(cells[mapping["search_rank"]]) if "search_rank" in mapping and mapping["search_rank"] < len(cells) else "",
                "growth_pct": "",
                "click_concentration_pct": first_number(cells[mapping["click_concentration_pct"]]) if "click_concentration_pct" in mapping and mapping["click_concentration_pct"] < len(cells) else "",
                "ppc_bid_usd": first_number(ppc_bid),
                "traffic_cost_index": traffic_cost_index_from_bid(first_number(ppc_bid)),
                "captured_at": iso_now(),
                "source_query": context.keyword,
                "source_file": str(raw_path),
                "trend_surface_present": "是" if "trend_column" in mapping else "否",
                "raw_cells": cells,
            }
        )
    return rows


def main() -> int:
    args = parse_args()
    context = resolve_context_from_namespace(args, require_direction_id=False)
    output_dir = output_dir_from_namespace(args)
    log_dir = log_dir_from_namespace(args)
    raw_artifact_path = ensure_within_repo(output_dir / RAW_FILE_NAME, "raw_artifact_path")
    summary: dict[str, Any] = {
        "timestamp": iso_now(),
        "module": "keyword_trend",
        "status": "BLOCKED",
        "reason_code": "",
        "message": "",
        "context_source": context.context_source,
        "运行名称": context.run_name,
        "方向ID": context.direction_id,
        "方向词": context.keyword,
        "站点": context.site,
        "attempted_url": KEYWORD_TREND_URL,
        "final_url": "",
        "page_title": "",
        "guest_markers": [],
        "requests_after_query": [],
        "raw_artifact_path": "",
        "raw_row_count": 0,
        "dry_run": bool(args.dry_run),
    }

    try:
        if not PROFILE_DIR.exists():
            raise KeywordChainError(f"Persistent profile is missing: {PROFILE_DIR}", "PROFILE_MISSING")

        with sync_playwright() as playwright:
            request_log: list[dict[str, str]] = []
            context_browser = playwright.chromium.launch_persistent_context(
                str(PROFILE_DIR),
                channel="msedge",
                headless=True,
                accept_downloads=False,
                viewport={"width": 1600, "height": 1200},
            )
            page = context_browser.new_page()
            page.on(
                "request",
                lambda req: request_log.append({"method": req.method, "url": req.url})
                if "sellersprite.com" in req.url
                else None,
            )
            page.goto(KEYWORD_TREND_URL, wait_until="networkidle", timeout=90000)
            page.wait_for_timeout(3000)
            before_click = page_snapshot(page)
            summary["page_title"] = before_click["title"]
            summary["guest_markers"] = before_click["guest_markers"]

            query_input = page.locator(".single input[placeholder*='flashlight']")
            query_button = page.locator(".single .el-input-group__append button")
            if query_input.count() == 0 or query_button.count() == 0:
                raise KeywordChainError(
                    "Keyword trend research controls were not found on the current SellerSprite page surface.",
                    "KEYWORD_TREND_CONTROLS_MISSING",
                )

            query_input.first.click(timeout=10000)
            page.keyboard.press("Control+A")
            page.keyboard.type(context.keyword, delay=50)

            if args.dry_run:
                summary["status"] = "PASS"
                summary["reason_code"] = "DRY_RUN_ONLY"
                summary["message"] = "Dry-run validated the keyword trend page controls without dispatching a live query."
                summary["final_url"] = page.url
                context_browser.close()
                persist_run_summary(log_dir, "latest_keyword_trend_run.json", "keyword_trend_runs.jsonl", summary)
                print(json.dumps(summary, ensure_ascii=False, indent=2))
                return 0

            baseline_request_count = len(request_log)
            query_button.first.click(timeout=10000)
            page.wait_for_timeout(8000)
            summary["final_url"] = page.url
            summary["requests_after_query"] = request_log[baseline_request_count:]
            after_click = page_snapshot(page)
            summary["page_title"] = after_click["title"]
            summary["guest_markers"] = after_click["guest_markers"]

            seller_requests = [item for item in summary["requests_after_query"] if "sellersprite.com" in item["url"]]
            if not seller_requests:
                raise KeywordChainError(
                    "Keyword trend query click did not emit any SellerSprite request. Current page surface is reachable, but live trend query is still blocked or guest-gated.",
                    "KEYWORD_TREND_QUERY_BLOCKED",
                )

            tables = extract_tables(page)
            result_table = choose_result_table(tables)
            if result_table is None:
                raise KeywordChainError(
                    "Keyword trend page did not expose a stable result table after query dispatch.",
                    "KEYWORD_TREND_RESULT_TABLE_MISSING",
                )

            rows = parse_rows(result_table, context, raw_artifact_path)
            if not rows:
                raise KeywordChainError(
                    "Keyword trend result table was found, but no keyword rows were parsed.",
                    "KEYWORD_TREND_NO_ROWS",
                )

            raw_artifact = {
                "module": "keyword_trend",
                "status": "PASS",
                "timestamp": iso_now(),
                "url": page.url,
                "title": page.title(),
                "context": {
                    "run_name": context.run_name,
                    "direction_id": context.direction_id,
                    "keyword": context.keyword,
                    "site": context.site,
                    "category_hint": context.category_hint,
                },
                "rows": rows,
            }
            output_dir.mkdir(parents=True, exist_ok=True)
            write_json_atomic(raw_artifact_path, raw_artifact)

            summary["status"] = "PASS"
            summary["reason_code"] = "PASS"
            summary["message"] = "Keyword trend raw rows collected successfully."
            summary["raw_artifact_path"] = str(raw_artifact_path)
            summary["raw_row_count"] = len(rows)
            context_browser.close()
    except KeywordChainError as exc:
        summary["status"] = "BLOCKED"
        summary["reason_code"] = exc.reason_code
        summary["message"] = str(exc)
    except Exception as exc:
        summary["status"] = "BLOCKED"
        summary["reason_code"] = "KEYWORD_TREND_UNHANDLED_ERROR"
        summary["message"] = str(exc)

    persist_run_summary(log_dir, "latest_keyword_trend_run.json", "keyword_trend_runs.jsonl", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if summary["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
