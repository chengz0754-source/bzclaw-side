from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Any

from keyword_chain_common import (
    OUTPUTS_ROOT,
    ROOT,
    ensure_within_repo,
    iso_now,
    load_csv_rows,
    parse_int_value,
    safe_float,
    timestamp_slug,
    write_csv_atomic,
    write_json_atomic,
)


DEFAULT_BATCH_SUMMARY = ROOT / "logs" / "direction_batch" / "latest_run.json"
DEFAULT_LOG_DIR = ROOT / "logs" / "candidate_pool"
STANDARD_99_PATH = ROOT / "templates" / "selection_canonical_standards" / "99_字段数据标准总表.csv"

INTERMEDIATE_FILE = "03_候选市场与候选品初筛池.csv"
FINAL_FILE = "60_候选样品池.csv"
FINAL_MD = "60_候选样品池.md"
SUMMARY_JSON = "candidate_pool_summary.json"
LATEST_RUN_FILE = "latest_run.json"
RUN_HISTORY_FILE = "candidate_pool_runs.jsonl"
RUN_FAILURE_FILE = "candidate_pool_failures.jsonl"

STEP4_SEED_FILE = "41_候选产品种子池.csv"
STEP4_GATE_FILE = "42_竞品基准下推结果.csv"

INTERMEDIATE_FIELDS = [
    "运行名称",
    "方向ID",
    "方向词",
    "来源关键词",
    "站点",
    "样品ID",
    "样品ASIN",
    "样品标题",
    "品牌",
    "市场路径",
    "候选市场名称",
    "样品价格",
    "评分",
    "评论数",
    "去重组ID",
    "近义合并组ID",
    "样品来源阶段",
    "样品来源批次号",
    "来源记录",
    "市场下推状态",
    "竞品下推状态",
    "关键词价值状态",
    "广告依赖状态",
    "当前池状态",
    "备注",
]

TITLE_STOPWORDS = {
    "the",
    "and",
    "for",
    "with",
    "pack",
    "pcs",
    "piece",
    "pieces",
    "toy",
    "toys",
    "fidget",
    "squishy",
    "squeeze",
    "stress",
    "ball",
    "balls",
    "kids",
    "kid",
    "adult",
    "adults",
    "mini",
    "small",
    "sensory",
    "stuffers",
    "stuffer",
}


class CandidatePoolError(RuntimeError):
    def __init__(self, message: str, reason_code: str = "CANDIDATE_POOL_ERROR") -> None:
        super().__init__(message)
        self.reason_code = reason_code


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Build the runtime intermediate candidate pool and final 60 candidate pool from structured STEP3/STEP4 outputs.",
    )
    parser.add_argument("--batch-summary", default=str(DEFAULT_BATCH_SUMMARY))
    parser.add_argument("--queue-csv", default=None)
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--log-dir", default=str(DEFAULT_LOG_DIR))
    parser.add_argument("--batch-id", default=None)
    return parser.parse_args()


def repo_path(raw_path: str | None, label: str) -> Path:
    if not raw_path:
        raise CandidatePoolError(f"Missing path for {label}.", "PATH_MISSING")
    path = Path(raw_path).expanduser()
    if not path.is_absolute():
        path = ROOT / path
    return ensure_within_repo(path, label)


def default_output_dir(batch_id: str) -> Path:
    return ensure_within_repo(OUTPUTS_ROOT / batch_id / "02_generated_outputs", "output_dir")


def append_jsonl(path: Path, payload: Any) -> None:
    ensure_within_repo(path, "jsonl_path")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(payload, ensure_ascii=False) + "\n")


def load_dict_rows(path: Path) -> list[dict[str, str]]:
    rows = load_csv_rows(path)
    if not rows:
        return []
    headers = rows[0]
    return [
        {header: row[idx] if idx < len(row) else "" for idx, header in enumerate(headers)}
        for row in rows[1:]
    ]


def load_field_order(file_name: str) -> list[str]:
    rows = list(csv.DictReader(STANDARD_99_PATH.read_text(encoding="utf-8-sig").splitlines()))
    return [row["field_name"] for row in rows if row["file_name"] == file_name]


def parse_snapshot(raw_value: str) -> dict[str, Any]:
    text = str(raw_value or "").strip()
    if not text:
        return {}
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return {"raw_snapshot": text}
    return payload if isinstance(payload, dict) else {"value": payload}


def normalize_status(value: str) -> str:
    normalized = str(value or "").strip().upper()
    if normalized in {"PASS", "FAIL", "HOLD"}:
        return normalized
    if normalized == "BLOCKED":
        return "HOLD"
    return "HOLD"


def join_unique(values: list[str]) -> str:
    seen: list[str] = []
    for value in values:
        text = str(value or "").strip()
        if text and text not in seen:
            seen.append(text)
    return "; ".join(seen)


def stable_id(prefix: str, *parts: str) -> str:
    raw = "|".join(str(part or "").strip() for part in parts if str(part or "").strip())
    digest = hashlib.sha1(raw.encode("utf-8")).hexdigest()[:10].upper()
    return f"{prefix}_{digest}"


def normalize_title_tokens(title: str) -> list[str]:
    tokens = re.findall(r"[0-9A-Za-z\u4e00-\u9fff]+", str(title or "").casefold())
    normalized: list[str] = []
    for token in tokens:
        if len(token) <= 2 or token in TITLE_STOPWORDS:
            continue
        if token.endswith("s") and len(token) > 4:
            token = token[:-1]
        if token not in normalized:
            normalized.append(token)
    return normalized


def merge_group_id(title: str, brand: str, market_name: str) -> str:
    signature = "|".join(normalize_title_tokens(title)[:5]) or str(title or "").strip().casefold()
    return stable_id("MERGE", brand.casefold(), market_name.casefold(), signature)


def candidate_score(row: dict[str, str]) -> tuple[float, float, float, str]:
    reviews = safe_float(row.get("评论数")) or 0.0
    rating = safe_float(row.get("评分")) or 0.0
    price = safe_float(row.get("样品价格")) or 0.0
    return (reviews, rating, price, row.get("样品ASIN", ""))


def aggregate_status(values: list[str], blank_default: str = "HOLD") -> str:
    normalized = [normalize_status(value) for value in values if str(value or "").strip()]
    if not normalized:
        return blank_default
    if any(value == "FAIL" for value in normalized):
        return "FAIL"
    if any(value == "HOLD" for value in normalized):
        return "HOLD"
    return "PASS"


def split_keywords(keywords: list[str]) -> tuple[str, str]:
    unique_keywords = [value for value in keywords if str(value or "").strip()]
    if not unique_keywords:
        return "", ""
    core = "; ".join(unique_keywords[:3])
    long_tail = "; ".join(unique_keywords[3:])
    return core, long_tail


def write_markdown(path: Path, content: str) -> None:
    ensure_within_repo(path, "markdown_path")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def load_batch_summary(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise CandidatePoolError(f"Direction batch summary is missing: {path}", "DIRECTION_BATCH_SUMMARY_MISSING")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise CandidatePoolError(f"Direction batch summary is not a JSON object: {path}", "DIRECTION_BATCH_SUMMARY_INVALID")
    return payload


def queue_index(rows: list[dict[str, str]]) -> dict[tuple[str, str, str], dict[str, str]]:
    indexed: dict[tuple[str, str, str], dict[str, str]] = {}
    for row in rows:
        key = (
            str(row.get("row_index", "")).strip(),
            str(row.get("关键词", "")).strip(),
            str(row.get("stage_code", "")).strip(),
        )
        indexed[key] = row
    return indexed


def first_matching_gate_row(rows: list[dict[str, str]], sample_id: str, sample_asin: str) -> dict[str, str]:
    for row in rows:
        if str(row.get("样品ID", "")).strip() == sample_id:
            return row
    for row in rows:
        if str(row.get("样品ASIN", "")).strip().upper() == sample_asin.upper():
            return row
    return {}


def build_source_rows(queue_rows: list[dict[str, str]]) -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
    indexed_queue = queue_index(queue_rows)
    source_rows: list[dict[str, Any]] = []
    blocked_rows: list[dict[str, str]] = []

    for queue_row in queue_rows:
        stage_code = str(queue_row.get("stage_code", "")).strip()
        if stage_code != "STEP4_BENCHMARK_TRIGGER":
            continue
        keyword = str(queue_row.get("关键词", "")).strip()
        row_index = str(queue_row.get("row_index", "")).strip()
        if normalize_status(queue_row.get("status", "")) != "PASS":
            blocked_rows.append(
                {
                    "row_index": row_index,
                    "方向词": str(queue_row.get("方向词", "")).strip(),
                    "关键词": keyword,
                    "reason_code": str(queue_row.get("reason_code", "")).strip(),
                }
            )
            continue

        trigger_snapshot = parse_snapshot(queue_row.get("data_snapshot", ""))
        build_summary = trigger_snapshot.get("build_summary", {})
        if not isinstance(build_summary, dict) or str(build_summary.get("status", "")).strip().upper() != "PASS":
            blocked_rows.append(
                {
                    "row_index": row_index,
                    "方向词": str(queue_row.get("方向词", "")).strip(),
                    "关键词": keyword,
                    "reason_code": "STEP4_BUILD_SUMMARY_MISSING",
                }
            )
            continue

        benchmark_output_dir = repo_path(str(build_summary.get("output_dir", "")), "benchmark_output_dir")
        seed_path = ensure_within_repo(benchmark_output_dir / STEP4_SEED_FILE, "seed_path")
        gate_path = ensure_within_repo(benchmark_output_dir / STEP4_GATE_FILE, "gate_path")
        if not seed_path.exists() or not gate_path.exists():
            blocked_rows.append(
                {
                    "row_index": row_index,
                    "方向词": str(queue_row.get("方向词", "")).strip(),
                    "关键词": keyword,
                    "reason_code": "STEP4_OUTPUT_FILES_MISSING",
                }
            )
            continue

        seed_rows = load_dict_rows(seed_path)
        gate_rows = load_dict_rows(gate_path)
        if not seed_rows:
            blocked_rows.append(
                {
                    "row_index": row_index,
                    "方向词": str(queue_row.get("方向词", "")).strip(),
                    "关键词": keyword,
                    "reason_code": "STEP4_SEED_ROWS_EMPTY",
                }
            )
            continue

        step2_row = indexed_queue.get((row_index, keyword, "STEP2_KEYWORD_GATE"), {})
        step3_row = indexed_queue.get((row_index, keyword, "STEP3_MARKET_GATE"), {})
        step4_gate_row = indexed_queue.get((row_index, keyword, "STEP4_BENCHMARK_GATE"), {})
        step3_snapshot = parse_snapshot(step3_row.get("data_snapshot", ""))
        matched_step3 = step3_snapshot.get("matched_step3_gate_rows", [])
        market_gate_row = matched_step3[0] if isinstance(matched_step3, list) and matched_step3 else {}

        export_summary = trigger_snapshot.get("export_summary", {})
        source_stage = "STEP4_BENCHMARK"
        source_keyword = keyword
        direction_word = str(queue_row.get("方向词", "")).strip()
        site = str(market_gate_row.get("站点", "")).strip() or str(export_summary.get("站点", "")).strip()
        keyword_value_status = normalize_status(step2_row.get("status", "HOLD"))
        market_status = normalize_status(str(market_gate_row.get("整体状态", "")).strip() or step3_row.get("status", "HOLD"))

        for seed_row in seed_rows:
            gate_row = first_matching_gate_row(
                gate_rows,
                sample_id=str(seed_row.get("样品ID", "")).strip(),
                sample_asin=str(seed_row.get("样品ASIN", "")).strip(),
            )
            benchmark_status = normalize_status(str(gate_row.get("整体状态", "")).strip() or build_summary.get("gate_status", "HOLD"))
            ad_dependency_status = "HOLD"
            current_pool_status = aggregate_status([keyword_value_status, market_status, benchmark_status, ad_dependency_status])
            step3_batch = str(market_gate_row.get("下推批次号", "")).strip()
            step4_batch = str(gate_row.get("下推批次号", "")).strip() or str(build_summary.get("benchmark_run_summary", "")).strip()

            source_rows.append(
                {
                    "运行名称": str(seed_row.get("运行名称", "")).strip(),
                    "方向ID": str(seed_row.get("方向ID", "")).strip(),
                    "方向词": direction_word,
                    "来源关键词": source_keyword,
                    "站点": site,
                    "样品ID": str(seed_row.get("样品ID", "")).strip(),
                    "样品ASIN": str(seed_row.get("样品ASIN", "")).strip().upper(),
                    "样品标题": str(seed_row.get("样品标题", "")).strip(),
                    "品牌": str(seed_row.get("品牌", "")).strip(),
                    "市场路径": str(seed_row.get("市场路径", "")).strip() or str(export_summary.get("market_path", "")).strip(),
                    "候选市场名称": str(seed_row.get("候选市场名称", "")).strip() or str(export_summary.get("candidate_market_name", "")).strip(),
                    "样品价格": str(seed_row.get("价格", "")).strip(),
                    "评分": str(seed_row.get("评分", "")).strip(),
                    "评论数": str(seed_row.get("评论数", "")).strip(),
                    "去重组ID": str(seed_row.get("去重组ID", "")).strip(),
                    "近义合并组ID": merge_group_id(str(seed_row.get("样品标题", "")), str(seed_row.get("品牌", "")), str(seed_row.get("候选市场名称", ""))),
                    "样品来源阶段": source_stage,
                    "样品来源批次号": step4_batch,
                    "来源记录": join_unique(
                        [
                            f"DIRECTION:{direction_word}",
                            f"KEYWORD:{source_keyword}",
                            f"STEP2:{keyword_value_status}",
                            f"STEP3:{step3_batch}",
                            f"STEP4:{step4_batch}",
                        ]
                    ),
                    "市场下推状态": market_status,
                    "竞品下推状态": benchmark_status,
                    "关键词价值状态": keyword_value_status,
                    "广告依赖状态": ad_dependency_status,
                    "当前池状态": current_pool_status,
                    "备注": "",
                    "_market_avg_price": str(market_gate_row.get("平均价格", "")).strip(),
                    "_market_monthly_sales": str(market_gate_row.get("月总销量", "")).strip(),
                    "_market_new_product_ratio": str(market_gate_row.get("新品占比_pct", "")).strip(),
                    "_market_product_concentration": str(market_gate_row.get("商品集中度", "")).strip(),
                    "_market_brand_concentration": str(market_gate_row.get("品牌集中度", "")).strip(),
                    "_market_seller_concentration": str(market_gate_row.get("卖家集中度", "")).strip(),
                }
            )

    return source_rows, blocked_rows


def merge_source_rows(source_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in source_rows:
        grouped[str(row.get("样品ASIN", "")).strip().upper()].append(row)

    merged_rows: list[dict[str, Any]] = []
    for sample_asin, rows in grouped.items():
        representative = sorted(rows, key=candidate_score, reverse=True)[0]
        direction_ids = [str(row.get("方向ID", "")).strip() for row in rows]
        direction_words = [str(row.get("方向词", "")).strip() for row in rows]
        source_keywords = [str(row.get("来源关键词", "")).strip() for row in rows]
        sample_ids = [str(row.get("样品ID", "")).strip() for row in rows]
        source_records = [str(row.get("来源记录", "")).strip() for row in rows]
        core_keywords, long_tail_keywords = split_keywords(sorted({value for value in source_keywords if value}))
        merged_rows.append(
            {
                "运行名称": join_unique([str(row.get("运行名称", "")).strip() for row in rows]),
                "方向ID": join_unique(direction_ids),
                "方向词": join_unique(direction_words),
                "站点": str(representative.get("站点", "")).strip(),
                "样品ID": str(representative.get("样品ID", "")).strip(),
                "样品ASIN": sample_asin,
                "样品标题": str(representative.get("样品标题", "")).strip(),
                "品牌": str(representative.get("品牌", "")).strip(),
                "市场路径": str(representative.get("市场路径", "")).strip(),
                "候选市场名称": str(representative.get("候选市场名称", "")).strip(),
                "核心关键词": core_keywords,
                "长尾关键词": long_tail_keywords,
                "平均价格": str(representative.get("_market_avg_price", "")).strip(),
                "月总销量": str(representative.get("_market_monthly_sales", "")).strip(),
                "新品占比_pct": str(representative.get("_market_new_product_ratio", "")).strip(),
                "商品集中度": str(representative.get("_market_product_concentration", "")).strip(),
                "品牌集中度": str(representative.get("_market_brand_concentration", "")).strip(),
                "卖家集中度": str(representative.get("_market_seller_concentration", "")).strip(),
                "自然流量占比_pct": "",
                "广告流量占比_pct": "",
                "推荐流量占比_pct": "",
                "建议竞价中位数": "",
                "关键词价值状态": aggregate_status([str(row.get("关键词价值状态", "")).strip() for row in rows]),
                "广告依赖状态": aggregate_status([str(row.get("广告依赖状态", "")).strip() for row in rows]),
                "当前下推状态": aggregate_status([str(row.get("当前池状态", "")).strip() for row in rows]),
                "合规": "",
                "改良点": "",
                "最终解释": "",
                "利润核价": "",
                "备注": "",
                "_source_sample_ids": join_unique(sample_ids),
                "_source_records": join_unique(source_records),
                "_merge_group_id": str(representative.get("近义合并组ID", "")).strip(),
                "_dedupe_group_ids": join_unique([str(row.get("去重组ID", "")).strip() for row in rows]),
            }
        )

    merged_rows.sort(
        key=lambda row: (
            safe_float(row.get("月总销量")) or 0.0,
            safe_float(row.get("平均价格")) or 0.0,
            row.get("样品ASIN", ""),
        ),
        reverse=True,
    )
    return merged_rows


def markdown_summary(summary: dict[str, Any], rows_60: list[dict[str, Any]]) -> str:
    lines = [
        "# 60 候选样品池",
        "",
        f"- batch_id: `{summary['batch_id']}`",
        f"- status: `{summary['status']}`",
        f"- reason_code: `{summary['reason_code']}`",
        f"- source_queue_path: `{summary['queue_path']}`",
        f"- intermediate_rows: `{summary['intermediate_row_count']}`",
        f"- final_rows: `{summary['final_row_count']}`",
        f"- contributing_directions: `{summary['contributing_direction_count']}`",
        "",
        "## Upstream",
        "",
        f"- direction_batch_status: `{summary['direction_batch_status']}`",
        f"- direction_batch_reason: `{summary['direction_batch_reason']}`",
        "",
        "## Candidate Pool",
        "",
        "| 样品ID | 样品ASIN | 方向词 | 核心关键词 | 候选市场名称 | 当前下推状态 |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    for row in rows_60:
        title = str(row.get("样品标题", "")).strip()
        truncated_title = title if len(title) <= 72 else title[:69] + "..."
        lines.append(
            f"| {row['样品ID']} | {row['样品ASIN']} | {row['方向词']} | {row['核心关键词']} | {row['候选市场名称']} | {row['当前下推状态']} |"
        )
        lines.append(f"|  |  |  |  | `{truncated_title}` |  |")
    if not rows_60:
        lines.append("| - | - | - | - | - | - |")

    blocked = summary.get("blocked_rows", [])
    if blocked:
        lines.extend(
            [
                "",
                "## Blocked Rows",
                "",
                "| row_index | 方向词 | 关键词 | reason_code |",
                "| --- | --- | --- | --- |",
            ]
        )
        for item in blocked:
            lines.append(
                f"| {item['row_index']} | {item['方向词']} | {item['关键词']} | {item['reason_code']} |"
            )

    lines.extend(
        [
            "",
            "## Manual Fields",
            "",
            "- `合规` 保持留空",
            "- `改良点` 保持留空",
            "- `最终解释` 保持留空",
            "- `利润核价` 保持留空",
            "- `备注` 在本轮保持留空",
        ]
    )
    return "\n".join(lines) + "\n"


def persist_logs(log_dir: Path, summary: dict[str, Any]) -> None:
    log_dir.mkdir(parents=True, exist_ok=True)
    write_json_atomic(log_dir / LATEST_RUN_FILE, summary)
    append_jsonl(log_dir / RUN_HISTORY_FILE, summary)
    if summary["status"] != "PASS":
        append_jsonl(log_dir / RUN_FAILURE_FILE, summary)


def main() -> int:
    args = parse_args()
    batch_id = str(args.batch_id or f"CANDIDATE_POOL_{timestamp_slug()}")
    batch_summary_path = repo_path(args.batch_summary, "batch_summary")
    log_dir = repo_path(args.log_dir, "log_dir")
    output_dir = repo_path(args.output_dir, "output_dir") if args.output_dir else default_output_dir(batch_id)
    output_dir.mkdir(parents=True, exist_ok=True)

    direction_batch_summary = load_batch_summary(batch_summary_path)
    queue_path = repo_path(args.queue_csv, "queue_csv") if args.queue_csv else repo_path(direction_batch_summary.get("queue_path", ""), "queue_path")
    queue_rows = load_dict_rows(queue_path)
    source_rows, blocked_rows = build_source_rows(queue_rows)
    rows_60 = merge_source_rows(source_rows)

    intermediate_path = ensure_within_repo(output_dir / INTERMEDIATE_FILE, "intermediate_path")
    final_path = ensure_within_repo(output_dir / FINAL_FILE, "final_path")
    final_md_path = ensure_within_repo(output_dir / FINAL_MD, "final_md_path")
    summary_path = ensure_within_repo(output_dir / SUMMARY_JSON, "summary_path")

    write_csv_atomic(
        intermediate_path,
        INTERMEDIATE_FIELDS,
        [[str(row.get(field, "")).strip() for field in INTERMEDIATE_FIELDS] for row in source_rows],
    )
    final_field_order = load_field_order(FINAL_FILE)
    write_csv_atomic(
        final_path,
        final_field_order,
        [[str(row.get(field, "")).strip() for field in final_field_order] for row in rows_60],
    )

    status = "PASS"
    reason_code = "PASS"
    if direction_batch_summary.get("status") != "PASS":
        status = "HOLD"
        upstream_reason = str(direction_batch_summary.get("reason_code", "DIRECTION_BATCH_NOT_PASS")).strip()
        if upstream_reason.startswith("BLOCKED_BY_UPSTREAM_CHAIN__"):
            reason_code = upstream_reason
        else:
            reason_code = f"BLOCKED_BY_UPSTREAM_CHAIN__{upstream_reason}"
    if not rows_60:
        status = "HOLD"
        reason_code = "NO_REAL_CANDIDATE_ROWS"

    summary = {
        "timestamp": iso_now(),
        "module": "candidate_pool_build",
        "batch_id": batch_id,
        "status": status,
        "reason_code": reason_code,
        "batch_summary_path": str(batch_summary_path),
        "queue_path": str(queue_path),
        "direction_batch_status": str(direction_batch_summary.get("status", "")).strip(),
        "direction_batch_reason": str(direction_batch_summary.get("reason_code", "")).strip(),
        "intermediate_path": str(intermediate_path),
        "final_path": str(final_path),
        "final_md_path": str(final_md_path),
        "intermediate_row_count": len(source_rows),
        "final_row_count": len(rows_60),
        "contributing_direction_count": len({str(row.get("方向词", "")).strip() for row in rows_60 if str(row.get("方向词", "")).strip()}),
        "blocked_rows": blocked_rows,
    }

    write_json_atomic(summary_path, summary)
    write_markdown(final_md_path, markdown_summary(summary, rows_60))
    persist_logs(log_dir, summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if status == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
